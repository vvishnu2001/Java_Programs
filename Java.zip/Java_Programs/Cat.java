package org.example;

public class Cat extends Animal{

public void eat()
{
    System.out.println("Cat is eat");
}

}


