package org.example;

public interface Car {
    void color();
}
