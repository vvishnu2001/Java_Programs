package org.example;

public class Audi implements Car{
    @Override
    public void color() {
        System.out.println("The Colour of Audi is Black");
    }
}
