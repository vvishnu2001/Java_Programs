package org.example;

public class Main {
    public static void main(String[] args) {
    Car volvo = new Volvo();
    Car audi = new Audi();

//    useCar(volvo);
//    useCar(audi);

        volvo.color();


    }

    private static void useCar(Car carname) {

    }
}