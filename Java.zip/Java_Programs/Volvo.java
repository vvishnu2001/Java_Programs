package org.example;

public class Volvo implements Car{
    @Override
    public void color() {
        System.out.println("The Colour of Volvo is Blue");
    }
}
