package org.example;

import java.io.IOException;

public class Connection {
    public Connection getConnection() throws IOException{
        throw new IOException();
    }

}
